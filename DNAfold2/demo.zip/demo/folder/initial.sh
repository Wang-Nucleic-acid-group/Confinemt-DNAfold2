#!/bin/bash
cd initial
g++ seq_initial.c
./a.out
cp ch.dat ../model
cd ..
