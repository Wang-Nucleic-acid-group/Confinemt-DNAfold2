#!/bin/bash
cd scoring
bash 1.sh
cd ..

