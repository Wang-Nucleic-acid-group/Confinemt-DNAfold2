#!/bin/bash
cp config1.dat scoring
cd scoring
bash 2.sh
cd ..

